"use strict";(()=>{var e={};e.id=726,e.ids=[726],e.modules={145:e=>{e.exports=require("next/dist/compiled/next-server/pages-api.runtime.prod.js")},2785:e=>{e.exports=require("next/dist/compiled/next-server/pages.runtime.prod.js")},6689:e=>{e.exports=require("react")},6405:e=>{e.exports=require("react-dom")},2079:e=>{e.exports=import("openai")},7147:e=>{e.exports=require("fs")},2781:e=>{e.exports=require("stream")},9796:e=>{e.exports=require("zlib")},6429:(e,i,o)=>{o.a(e,async(e,a)=>{try{o.r(i),o.d(i,{config:()=>c,default:()=>r,routeModule:()=>v});var t=o(1802),n=o(7153),s=o(6249),d=o(8183),l=e([d]);d=(l.then?(await l)():l)[0];let r=(0,s.l)(d,"default"),c=(0,s.l)(d,"config"),v=new t.PagesAPIRouteModule({definition:{kind:n.x.PAGES_API,page:"/api/evaluate_code",pathname:"/api/evaluate_code",bundlePath:"",filename:""},userland:d});a()}catch(e){a(e)}})},8183:(e,i,o)=>{o.a(e,async(e,a)=>{try{o.r(i),o.d(i,{default:()=>l});var t=o(2079);o(6821);var n=e([t]);t=(n.then?(await n)():n)[0];let r=process.env.AI_KEY_PB,c=new t.default({apiKey:r});async function s(e){let i=await c.chat.completions.create({messages:[{role:"system",content:e}],model:"gpt-4"});return console.log(i.choices[0]),{query:e,answer:i.choices[0]}}async function d(e){try{return JSON.parse(e)}catch(i){return e.substring(e.indexOf("{"),e.lastIndexOf("}"))+"}"}}async function l(e,i){if("POST"==e.method)i.status(200).json({text:"API is running"});else if("GET"==e.method){let o=e.query.question;console.log(o);let a=JSON.parse(o),t=a.code.replace("plus_plus","+"),n=a.mode,l=a.test;console.log("code "+t);let r="";if("no"==l){r="Python"==n?`I wish to have a JSON object with following structure
          {
            valid: valid/invalid,
            Reasoning: Why is code valid or invalid. If valid how can it be improved

          }
          I am providing python code within code tags <code>${t}</code>
          `:"OCR"==n?`I wish to have a JSON object with following structure
          {
            valid: valid/invalid,
            Reasoning: Why is code valid or invalid. If valid how can it be improved,
            code: equivalent python code if valid otherwise null

          }
          I am providing GCSE OCR ERL Exam Reference Language for Algorithims within code tags <code>${t}</code>
          `:`I wish to have a JSON object with following structure
          {
            valid: valid/invalid,
            Reasoning: Why is code valid or invalid. If valid how can it be improved,
            code: equivalent python code if valid otherwise null

          }
          I am providing coding steps within code tags <code>${t}</code>
          `,console.log(r);let e=(await s(r)).answer.message.content,o=await d(e);console.log(o),i.status(200).json(o)}else{let e=a.marks;a.topic,r="Python"==n?`I wish to have a JSON object with following structure
        {
          valid: valid/invalid,
          Reasoning: Why is code valid or invalid. If valid how can it be improved,
          code: equivalent python code if valid otherwise null
          marks: marks out of ${e}

        }
        I am providing python code within code tags <code>${t}</code>
        `:"OCR"==n?`I wish to have a JSON object with following structure
        {
          valid: valid/invalid,
          Reasoning: Why is code valid or invalid. If valid how can it be improved,
          code: equivalent python code if valid otherwise null
          marks: marks out of ${e}

        }
        I am providing GCSE OCR ERL Exam Reference Language for Algorithims within code tags <code>${t}</code>
        `:`I wish to have a JSON object with following structure
        {
          valid: valid/invalid,
          Reasoning: Why is code valid or invalid. If valid how can it be improved,
          code: equivalent python code if valid otherwise null
          marks: marks out of ${e}

        }
        I am providing coding steps within code tags <code>${t}</code>
        `,console.log(r);let o=(await s(r)).answer.message.content,l=await d(o);console.log(l),i.status(200).json(l)}}}a()}catch(e){a(e)}})}};var i=require("../../webpack-api-runtime.js");i.C(e);var o=e=>i(i.s=e),a=i.X(0,[484],()=>o(6429));module.exports=a})();