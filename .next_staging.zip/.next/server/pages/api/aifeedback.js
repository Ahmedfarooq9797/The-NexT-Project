"use strict";(()=>{var e={};e.id=188,e.ids=[188],e.modules={145:e=>{e.exports=require("next/dist/compiled/next-server/pages-api.runtime.prod.js")},2785:e=>{e.exports=require("next/dist/compiled/next-server/pages.runtime.prod.js")},6689:e=>{e.exports=require("react")},6405:e=>{e.exports=require("react-dom")},2079:e=>{e.exports=import("openai")},7147:e=>{e.exports=require("fs")},2781:e=>{e.exports=require("stream")},9796:e=>{e.exports=require("zlib")},6265:(e,t,n)=>{n.a(e,async(e,r)=>{try{n.r(t),n.d(t,{config:()=>l,default:()=>m,routeModule:()=>c});var u=n(1802),a=n(7153),i=n(6249),s=n(6964),o=e([s]);s=(o.then?(await o)():o)[0];let m=(0,i.l)(s,"default"),l=(0,i.l)(s,"config"),c=new u.PagesAPIRouteModule({definition:{kind:a.x.PAGES_API,page:"/api/aifeedback",pathname:"/api/aifeedback",bundlePath:"",filename:""},userland:s});r()}catch(e){r(e)}})},6964:(e,t,n)=>{n.a(e,async(e,r)=>{try{n.r(t),n.d(t,{default:()=>s});var u=n(2079);n(6821);var a=e([u]);u=(a.then?(await a)():a)[0];let o=process.env.AI_KEY_PB,m=new u.default({apiKey:o});async function i(e){let t=await m.chat.completions.create({messages:[{role:"system",content:e}],model:"gpt-4"});return console.log(t.choices[0]),{query:e,answer:t.choices[0]}}async function s(e,t){if("POST"==e.method)t.status(200).json({text:"API is running"});else if("GET"==e.method){let n=`
      
    Take two arguments from user
    Take the sum of two arguments
    Return the sum


    `;n=`
    # Python program for simple calculator

    # Function to add two numbers
    def add(num1, num2):
            return num1 + num2
    
    # Function to subtract two numbers
    def subtract(num1, num2):
            return num1 - num2
    
    # Function to multiply two numbers
    def multiply(num1, num2):
            return num1 * num2
    
    # Function to divide two numbers
    def divide(num1, num2):
            return num1 / num2
    
    print("Please select operation -
" \
                    "1. Add
" \
                    "2. Subtract
" \
                    "3. Multiply
" \
                    "4. Divide
")
    
    
    # Take input from the user
    select = int(input("Select operations form 1, 2, 3, 4 :"))
    
    number_1 = int(input("Enter first number: "))
    number_2 = int(input("Enter second number: "))
    
    if select == 1:
            print(number_1, "+", number_2, "=",
                                            add(number_1, number_2))
    
    elif select == 2:
            print(number_1, "-", number_2, "=",
                                            subtract(number_1, number_2))
    
    elif select == 3:
            print(number_1, "*", number_2, "=",
                                            multiply(number_1, number_2))
    
    elif select == 4:
            print(number_1, "/", number_2, "=",
                                            divide(number_1, number_2))
    else:
            print("Invalid input")
    
`;let r=`
Marks: 6


• input and stores/uses value with message 

• attempt at repeating… 

•…correctly repeats number of times given as input 

• …correctly take number as input within loop and calculates total of these numbers 

• …correctly calculate an average (total/num) 

• Output both total and average 
`,u=`For Given python code ${n} evaluate results based on following criteria ${r} leniently and assign marks out of total marks in Criteria`;e.query.question;let a=await i(u);t.status(200).json({AI_Answer:a.answer.message.content})}}r()}catch(e){r(e)}})}};var t=require("../../webpack-api-runtime.js");t.C(e);var n=e=>t(t.s=e),r=t.X(0,[484],()=>n(6265));module.exports=r})();